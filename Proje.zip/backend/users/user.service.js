﻿const config = require('config.json');
const jwt = require('jsonwebtoken');
const knex = require('../knex');
const { first } = require('../knex');

// users hardcoded for simplicity, store in a db for production applications
/*const users = [{ id: 1, username: 'test', password: 'test', firstName: 'Test', lastName: 'User', type:'student' },
{ id: 2, username: 'admin', password: 'admin', firstName: 'AdT', lastName: 'AdUser', type:'admin' }];*/
 var adminList; 
 var studentList;
 //getAll();
knex('admins').select('*').then((data)=>{
    
    adminList = data;
});
knex('student').select('*').then((data)=>{
    
    studentList = data;
});
 


module.exports = {
    authenticate,
    getAll
};


async function authenticate({ username, password }) {
    
    let user; 
            
    let admin = adminList.find(a => a.code == username);
    let student = studentList.find(s => s.stu_code == username);
     
  
    if(admin && admin.password == password){
        user = {id:admin.code,username:'admin',password:admin.password,firstName: 'admin',lastName:'',type:'admin'};
    }
    else if(student && student.stu_pass == password){
        
        user = {id:student.stu_code,username:'student',password:student.stu_pass,
            firstName: student.stu_name, lastName:student.stu_surname,type:'student'};
    }
    else {throw 'Invalid username or password';}
    
    
    // create a jwt token that is valid for 7 days
    const token = jwt.sign({ sub: user.id }, config.secret, { expiresIn: '7d' });
    
    return {
        
        ...omitPassword(user),
        token
    };
}

async function getAll() {
    
    knex('admins').select('*').then((data)=>{
        adminList = data;
    });
    knex('student').select('*').then((data)=>{
        
        studentList = data;
    });
    
}


// helper functions
function omitPassword(user) {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
}