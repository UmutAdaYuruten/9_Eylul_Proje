﻿const express = require('express');
const router = express.Router();
const userService = require('./user.service');
const profileService = require('./profile-service');

// routes
router.post('/authenticate', authenticate);
router.get('/', getAll);

router.get('/profile/:id',getUser);
router.get('/profile',getStudent);

router.get('/user-lectures/:id',getUserLectures);
router.post('/user-lectures',addLecture);
router.delete('/user-lectures/:id', removeLecture)

module.exports = router;

function authenticate(req, res, next) {
   
    userService.authenticate(req.body)
        .then(user => res.json(user))
        .catch(next);
}

function getAll(req, res, next) {
   
    userService.getAll()
        .then(users => res.json(users))
        .catch(next);
}

function getUser(req,res,next){
    profileService.getUser(req.params.id)
        .then(users => res.json(users))
        .catch(next);
}

function getStudent(req,res,next){
    profileService.getStudent(req.body)
        .then(users => res.json(users))
        .catch(next);
}

function getUserLectures(req,res,next){
    profileService.getUserLectures(req.params.id)
        .then(users => res.json(users))
        .catch(next);
}

function addLecture(req,res,next){
    profileService.addLecture(req.body)
        .then(users => res.json(users))
        .catch(next);
}

function removeLecture(req,res,next){
    
    profileService.removeLecture(req.params.id)
        .then(users => res.json(users))
        .catch(next);
}