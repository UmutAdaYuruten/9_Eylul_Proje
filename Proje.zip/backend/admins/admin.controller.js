const express = require('express');
const router = express.Router();
const studentService = require('./student.service');
const lectureService = require('./lecture.service');
const academicService = require('./faculty-member.service');
const courseService = require('./course.service');
const classroomService = require('./classroom-service');
const userService = require('../users/user.service');

// routes
router.get('/courses', getCourses);
router.put('/courses/:id', updateCourse );
router.post('/courses',addCourse);
router.delete('/courses/:id', removeCourse);

router.get('/classrooms', getClassrooms);
router.put('/classrooms/:id', updateClassroom );
router.post('/classrooms',addClassroom);
router.delete('/classrooms/:id', removeClassroom);

router.get('/student/:id',getStudent)
router.get('/students', getStudents);
router.put('/students/:id', updateStudent);
router.post('/students', addStudent);
router.delete('/students/:id', removeStudent);

router.get('/lectures', getLectures);
router.put('/lectures/:id',updateLecture);
router.post('/lectures',addLecture);
router.delete('/lectures/:id',removeLecture);

router.get('/faculty-members', getMembers);
router.put('/faculty-members/:id',updateMember);
router.post('/faculty-members',addMember);
router.delete('/faculty-members/:id',removeMember);


module.exports = router;

// functions
//--------------Courses----------------------
function getCourses(req,res,next){
    
    courseService.getCourses()
        .then(result => res.json(result))
        .catch(next);
}

function addCourse(req,res,next){
    courseService.addCourse(req.body)
        .then(result => res.json(result))
        .catch(next);
}

function removeCourse(req,res,next){
    
    courseService.removeCourse(req.params.id)
        .then(result => res.json(result))
        .catch(next);
}

function updateCourse(req,res,next){
    courseService.updateCourse(req.params.id,req.body)
        .then(result => res.json(result))
        .catch(next);    
}


//-------------Classrooms-------------------

function getClassrooms(req,res,next){
    
    classroomService.getClassrooms()
        .then(result => res.json(result))
        .catch(next);
}

function addClassroom(req,res,next){
    classroomService.addClassroom(req.body)
        .then(result => res.json(result))
        .catch(next);
}

function removeClassroom(req,res,next){
    
    classroomService.removeClassroom(req.params.id)
        .then(result => res.json(result))
        .catch(next);
}

function updateClassroom(req,res,next){
    classroomService.updateClassroom(req.params.id,req.body)
        .then(result => res.json(result))
        .catch(next);    
}

// ------------Students-------------------
function getStudent(req,res,next){
    console.log("getStu çalıştı");
    studentService.getStudent(req.params.id)
        .then(students => res.json(students))
        .catch(next);
    userService.getAll();
}

function getStudents(req, res, next) {
    
    studentService.getStudents()
        .then(students => res.json(students))
        .catch(next);
    userService.getAll();
}

function addStudent(req,res,next){
    
    studentService.addStudent(req.body)
        .then(result => res.json(result))
        .catch(next);
    userService.getAll();
}

function removeStudent(req,res,next){
    
    studentService.removeStudent(req.params.id)
        .then(result => res.json(result))
        .catch(next);
    userService.getAll();
}

function updateStudent(req,res,next){
    studentService.updateStudent(req.params.id,req.body)
        .then(result => res.json(result))
        .catch(next);    
    userService.getAll();
}



//----------------Lectures--------------------------
function getLectures(req,res,next){
    
    lectureService.getLectures()
        .then(lectures => res.json(lectures))
        .catch(next);
}

function addLecture(req,res,next){
    
    lectureService.addLecture(req.body)
        .then(lectures => res.json(lectures))
        .catch(next);
}

function updateLecture(req, res,next){
    
    lectureService.updateLecture(req.params.id,req.body)
        .then(lectures => res.json(lectures))
        .catch(next);
}

function removeLecture(req,res,next){
    
    lectureService.removeLecture(req.params.id)
        .then(lectures => res.json(lectures))
        .catch(next);
}


//-------------------Academic Members--------------------
function getMembers(req,res,next){
    academicService.getMembers()
    .then(members => res.json(members))
    .catch(next);
}

function addMember(req,res,next){
    console.log("Add Çalıştı");
    academicService.addMember(req.body)
        .then(lectures => res.json(lectures))
        .catch(next);
}

function updateMember(req, res,next){
    
    academicService.updateMember(req.params.id,req.body)
        .then(lectures => res.json(lectures))
        .catch(next);
}

function removeMember(req,res,next){
    
    academicService.removeMember(req.params.id)
        .then(lectures => res.json(lectures))
        .catch(next);
}



/*function findStudent(req,res,next){
    adminService.findStudent(req.body)
        .then(student => res.json(student))
        .catch(next);

}*/