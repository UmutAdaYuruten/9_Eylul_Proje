import { ClassroomService } from './services/classroom-service/classroom.service';
import { CourseService } from './services/course-service/course.service';
import { FormsModule } from '@angular/forms';
import { UserService } from './services/user-service/user.service';
import { FacultyMemberService } from './services/faculty-member-service/faculty-member.service';
import { LectureService } from './services/lecture-service/lecture.service';
import { StudentService } from './services/student-service/student.service';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ToastrModule } from "ngx-toastr";
import { SidebarModule } from './sidebar/sidebar.module';
import { FooterModule } from './shared/footer/footer.module';
import { NavbarModule} from './shared/navbar/navbar.module';
import { FixedPluginModule} from './shared/fixedplugin/fixedplugin.module';
import { ReactiveFormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { LoginPageComponent } from './pages/login-page/login-page.component';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { UserSidebarComponent } from './user-sidebar/user-sidebar.component';
import { BrowserModule } from '@angular/platform-browser';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';




@NgModule({
  declarations: [
    
    AppComponent,
    AdminLayoutComponent,
    LoginPageComponent,
    UserLayoutComponent,
    UserSidebarComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(AppRoutes,{
      useHash: true
    }),
    SidebarModule,
    NavbarModule,
    ToastrModule.forRoot(),
    FooterModule,
    FixedPluginModule
  ],
  providers: [ 
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }, 
    StudentService, LectureService, FacultyMemberService,UserService,CourseService,ClassroomService],
  bootstrap: [AppComponent]
})
export class AppModule { }
