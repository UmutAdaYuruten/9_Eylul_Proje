import { Component, OnInit } from '@angular/core';


export interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}

export const ROUTES: RouteInfo[] = [
    
    { path: '/admin/students',         title: 'Students',          icon:'nc-hat-3',    class: '' },
    { path: '/admin/lectures',      title: 'Lectures',          icon:'nc-paper',    class:''},
    { path: '/admin/faculty-members',title: 'Faculty Members',  icon:'nc-badge', class: '' },
    { path: '/admin/courses'        ,title: 'Courses       ',  icon:'nc-bullet-list-67', class: '' },
    { path: '/admin/classrooms'        ,title: 'Classrooms       ',  icon:'nc-layout-11', class: '' },
    
    
];

@Component({
    moduleId: module.id,
    selector: 'sidebar-cmp',
    templateUrl: 'sidebar.component.html',
})

export class SidebarComponent implements OnInit {
    public menuItems: any[];
    ngOnInit() {
        this.menuItems = ROUTES.filter(menuItem => menuItem);
    }
}
