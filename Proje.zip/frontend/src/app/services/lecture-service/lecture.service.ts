import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { Lecture } from 'app/models/lecture';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LectureService {
  
  private lectures :Lecture[]  /* =[{'code': 1, 'c_code': 'CME-101', 'floor': 'Floor-1','day':'MON','hour':'8:00','classroom': 'A' ,'isMandatory':true},
  {'code': 2, 'c_code': 'MATH-101', 'floor': 'Floor-1','day':'TUE','hour':'15:30', 'classroom': 'B','isMandatory':false  },
  {'code': 3, 'c_code': 'CME-121', 'floor': 'Floor-2','day':'FRI','hour':'10:45', 'classroom': 'A' ,'isMandatory':true }]*/

  constructor(private http: HttpClient) { }
  getLectures()
  {
    const url = `${environment.apiUrl}/admin/lectures`
    return  this.http.get<Lecture[]>(url)
    .pipe(map(lectures => {
      return lectures;
    }));
  }

  addLecture(lecture:Lecture):Observable<any>
  {
    debugger
    console.log("add lecture servis");
    const url = `${environment.apiUrl}/admin/lectures`;
    return this.http.post<any>(url,  lecture );
  }

  findLecture(lecture_id){
    //return this.lectures.find(s => s.code == lecture_id)
    return true;
  }

  updateLecture(lecture:any,old_id:string):Observable<any>
  {
    const url = `${environment.apiUrl}/admin/lectures/${old_id}`;
    return this.http.put<any>(url, lecture);
  }

  removeLecture(lectureCode:string):Observable<any>{

   
    const url = `${environment.apiUrl}/admin/lectures/${lectureCode}`;
    return this.http.delete<any>(url);
   
  }
  
}
