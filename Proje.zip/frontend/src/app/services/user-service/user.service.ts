import { Register } from './../../models/register';
import { Injectable } from '@angular/core';
import { User } from 'app/models/user';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) { }
    private currentLectures;

    setCurrentLectures(tempLectures){
      this.currentLectures = tempLectures;
      
    }
    
    getCurrentLectures(){
      return this.currentLectures;
    }

    getAll() {
        return this.http.get<User[]>(`${environment.apiUrl}/users`);
    }
    getUser(id:number){
      const url = `${environment.apiUrl}/user/profile/${id}`;
        return this.http.get<any[]>(url);
    }
    
    getUserLectures(id:number){
      const url = `${environment.apiUrl}/user/user-lectures/${id}`;
      return this.http.get<any[]>(url);
    }

    addLecture(register:Register){
      const url = `${environment.apiUrl}/user/user-lectures`;
      return this.http.post<any[]>(url,register);
    }

    removeLecture(id:string){
      
      const url = `${environment.apiUrl}/user/user-lectures/${id}`;
      return this.http.delete<any[]>(url);
    }
}
