import { Classroom } from './../../models/classroom';
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ClassroomService {

  constructor(private http: HttpClient) { }

  getClassrooms(){
    return  this.http.get<Classroom[]>(`${environment.apiUrl}/admin/classrooms`)
    .pipe(map(classrooms => {
      
      
      return classrooms;
    }));
  }

  addClassroom(classroom:Classroom):Observable<any>
  {
    
    const url = `${environment.apiUrl}/admin/classrooms`;
    return this.http.post<any>(url,  classroom );
      
  }

  updateClassroom(classroom:Classroom,anID:String):Observable<any>
  {
    const url = `${environment.apiUrl}/admin/classrooms/${anID}`;
    return this.http.put<any>(url, classroom);
    
  }
  
  removeClassroom(id:string):Observable<any>{
    const url = `${environment.apiUrl}/admin/classrooms/${id}`;
    return this.http.delete<any>(url );
   
  }
}
