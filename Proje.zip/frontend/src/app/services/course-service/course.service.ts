
import { Course } from './../../models/course';
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http: HttpClient) { }

  getCourses(){
    return  this.http.get<Course[]>(`${environment.apiUrl}/admin/courses`)
    .pipe(map(courses => {
      
      
      return courses;
    }));
  }
  addCourse(course:Course):Observable<any>
  {
    
    const url = `${environment.apiUrl}/admin/courses`;
    return this.http.post<any>(url,  course );
      
  }

  updateCourse(course:Course,anID:string):Observable<any>
  {
    const url = `${environment.apiUrl}/admin/courses/${anID}`;
    return this.http.put<any>(url, course);
    
  }
  
  removeCourse(id:string):Observable<any>{
    const url = `${environment.apiUrl}/admin/courses/${id}`;
    return this.http.delete<any>(url );
   
  }
  
}
