import { FacultyMember } from './../../models/faculty-member';
import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class FacultyMemberService {
  /*private facultyMembers :FacultyMember[] = [{'code': 1, 'name': 'Nesim', 'surname': 'Sabah','email': 'ada@mail.com','startdate': '8.1.00' },
    {'code': 2, 'name': 'Selçuk', 'surname': 'Erdem', 'email': 'birol@mail.com','startdate': '8.2.99'  },
    {'code': 3, 'name': 'Feyza', 'surname': 'Gül', 'email': 'onur@mail.com','startdate': '2.3.01'   }];*/

    constructor(private http: HttpClient) { }
    
  getMembers()
  {
    return  this.http.get<FacultyMember[]>(`${environment.apiUrl}/admin/faculty-members`)
    .pipe(map(members => {
     
      
      return members;
    }));
  }
  addMember(member:FacultyMember)
  {
    console.log("servis ulaştı");
    const url = `${environment.apiUrl}/admin/faculty-members`;
    return this.http.post<any>(url,  member );
      
  }
  updateMember(member:FacultyMember,anID:number)
  {
    const url = `${environment.apiUrl}/admin/faculty-members/${anID}`;
    return this.http.put<any>(url, member);
  }
  
  removeMember(id:number){
    const url = `${environment.apiUrl}/admin/faculty-members/${id}`;
    return this.http.delete<any>(url );
  }
  
}


/*findMember(mem_id:number){
  return this.facultyMembers.find(s => s.aca_code == mem_id);
}*/