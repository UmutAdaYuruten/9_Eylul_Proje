import { Student } from './../../models/student';
import { LectureService } from 'app/services/lecture-service/lecture.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { Lecture } from 'app/models/lecture';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
 /* private students :Student[]= [
  {'code': 1, 'name': 'Ada', 'surname': 'Yuruten' },

  {'code': 2, 'name': 'Birol', 'surname': 'Sabah' },

  {'code': 3, 'name': 'Onur', 'surname': 'Tezek' }]*/

  constructor(private http: HttpClient) {
    
   }
  public getStudents():Observable<Student[]>
  {
   
    return  this.http.get<Student[]>(`${environment.apiUrl}/admin/students`);
   
    
  }

  public getStudent(id)
  {

    
    const url = `${environment.apiUrl}/admin/students/${id}`;
    return  this.http.get<Student[]>(url);
    
    
  }
  addStudent(student:Student):Observable<any>
  {
    
    const url = `${environment.apiUrl}/admin/students`;
    return this.http.post<any>(url, student );
      
    
  }

  findStudent(stu_id:number){
    //return this.students.find(s => s.stu_code == stu_id);
    return true;
  }
  
  updateStudent(stu:Student,anID:number):Observable<any>
  {

    const url = `${environment.apiUrl}/admin/students/${anID}`;
    return this.http.put<any>(url, stu);
    
  }

  
  hasLecture(id:number,l_id:number){
    /*let test: boolean = false;
    let Astudent: Student = this.students.find(s => s.stucode == id);

    for(let i = 0; i < Astudent.lectures.length;i++){
      if(Astudent.lectures[i].id == l_id){ test = true;}
    }
    return test;*/
    return true;
  }
  
  removeStudent(student:Student):Observable<any>{
    const url = `${environment.apiUrl}/admin/students/${student.stu_code}`;
    return this.http.delete<any>(url );
   
  }
}
