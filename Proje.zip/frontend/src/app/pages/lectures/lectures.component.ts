import { Classroom } from './../../models/classroom';
import { FacultyMember } from 'app/models/faculty-member';
import { LectureService } from './../../services/lecture-service/lecture.service';
import { Component, OnInit } from '@angular/core';
import { Lecture } from 'app/models/lecture';

@Component({
  selector: 'app-lectures',
  templateUrl: './lectures.component.html',
  styleUrls: ['./lectures.component.css']
})
export class LecturesComponent implements OnInit {
  public lectures  = []; //: {lectures: Lecture[], members: FacultyMember[], classes: Classroom[]};

    public in_id :string;
    public in_Cid :string;
    public in_floor: string;
    public in_day:number;
    public in_hour:string;
    public in_class:string = null;
    private edit_id;
    private edit_Cid:string;
    private edit_floor;
    private edit_day;
    private edit_hour;
    private edit_classroom;
    private edit_aname;
    private edit_asname;
    private tempID;
    private tempCID;
    private isEdit :boolean= false;
  public isAdd = false;

  constructor(private _lectureService: LectureService) { }

  ngOnInit() {
   this.updatePage();
   
  }
  updatePage(){
    this._lectureService.getLectures().pipe().subscribe(data => {  
      this.lectures = data;
   });
  }

  add(){
    if(this.isAdd ){
        if ( this.in_id == null || this.in_Cid == "")
        {return;}
    
        let lecture :Lecture = {lec_code: this.in_id, c_code: this.in_Cid,
           day: this.in_day,hour: this.in_hour,a_code:null,class_no:this.in_class};
          
        this._lectureService.addLecture(lecture).subscribe(res => {
          
          console.log("Front request add lecture");
          
          if(res){
            setTimeout(() => {
              this.updatePage();}, 2000);
             
          }
          else{
            alert("Internal Server Error While Adding");
          }

        }, error => {alert(error)});
    }

    this.in_id = this.in_Cid = this.in_floor = this.in_day = this.in_hour = this.in_class = null;
  
    this.isAdd = !this.isAdd;
  }

  remove(id:string,c_id:string){

    if(this.tempID == id && this.tempCID == c_id ){
        this.isEdit = false;
    }
    let outP = id + "~" + c_id;

    this._lectureService.removeLecture(outP).subscribe(res => {
      if(res){
        setTimeout(() => {
          this.updatePage();}, 50);
      }
      else{
        alert("Internal Server Error while removing");
      }

    }, error => {alert(error)});
  }

  openEdit(id:string,c_id:string){

    this.tempID = id;
    this.tempCID = c_id;

    let lecture = this.lectures.find(s => s.lec_code == id && s.c_code == c_id);

    this.edit_id = lecture.lec_code;
    this.edit_Cid = lecture.c_code;
    this.edit_floor = lecture.parentcode;
    this.edit_day = lecture.day;
    this.edit_hour = lecture.hour;
    this.edit_classroom = lecture.class_name;
    this.edit_aname = lecture.aca_name;
    this.edit_asname =lecture.aca_surname;
    this.isEdit = true;
    
}
edit(){
    
  let lecture = this.lectures.find(s => s.lec_code == this.tempID && s.c_code == this.tempCID);
    
    lecture.lec_code = this.edit_id;
    lecture.c_code = this.edit_Cid;
    lecture.parentcode = this.edit_floor;
    lecture.day = this.edit_day;
    lecture.hour = this.edit_hour;
    lecture.class_name = this.edit_classroom;
    lecture.aca_name =this.edit_aname;
    lecture.aca_surname = this.edit_asname ;
    
    let old_id = this.tempID + "~" + this.tempCID;
    this._lectureService.updateLecture(lecture,old_id).subscribe(res => {

      if(res){
        setTimeout(() => {
          this.updatePage();}, 2000);
           
      }
      else{
        alert("Internal Server Error while updating");
      }

    }, error => {alert(error)});
        this.isEdit=false;
    
  }
  closeEdit(){
    this.isEdit = false;
  }
  closeAdd(){
    this.isAdd = false;
  }

}
