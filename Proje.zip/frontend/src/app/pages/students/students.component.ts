import { Component, OnInit } from '@angular/core';
import { Student } from './../../models/student';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FixedPluginComponent } from './../../shared/fixedplugin/fixedplugin.component';
import { StudentService } from './../../services/student-service/student.service';

import { BrowserModule }    from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {
  private in_id :number;
  private in_name :string ="";
  private in_Sname: string="";
  private in_pass:string;
  
  private edit_id: number;
  private edit_name ;
  private edit_Sname ;
  private edit_pass;
  
  private editArr :boolean[] = [];
  private isAdd = false;
  private isEdit:boolean = false;
  private students:Student[] = [];
  private idList: string[] = [];
  private tempID:number;

  constructor(private _studentService :StudentService){}
  
  ngOnInit(){
    this.updatePage();
  }
  updatePage(){
    this._studentService.getStudents().subscribe(data=>{  
      
      this.students = data;
      
   });
  }
 
  add(){
    
      if(this.isAdd){
          if(this.in_id == null || this.in_name == null || this.in_Sname == null){return;}    
          let student :Student = {stu_code: this.in_id, stu_name:this.in_name,
             stu_surname:this.in_Sname,stu_pass:((this.in_pass == "" || this.in_pass == null)? '1234': this.in_pass)};
          
          this._studentService.addStudent(student).subscribe(res => {

            if(res){
              this.updatePage()
              setTimeout(() => {
                this.updatePage();}, 2000);
                 
            }
            else{
              alert("Internal Server Error While Adding");
            }
 
          });
          this.in_id =  this.in_name = this.in_Sname = this.in_pass = null;
      }
      this.isAdd = !this.isAdd;
  }
  remove(student:Student){
      if(this.tempID == student.stu_code){
          this.isEdit = false;
      }
      
      this._studentService.removeStudent(student).subscribe(res => {

        if(res){
          this.updatePage();
          setTimeout(() => {
            this.updatePage();}, 2000);
             
        }
        else{
          alert("Internal Server Error while removing");
        }

      },err => {alert(err);});
  }
  openEdit(id:number){

      this.tempID = id;
      let student :Student = this.students.find(s => s.stu_code == id);
      
      this.edit_name = student.stu_name;
      this.edit_Sname = student.stu_surname;
      this.edit_id = student.stu_code;
      this.edit_pass = student.stu_pass;
      this.isEdit = true;
  }
  edit(){
      
      let student = this.students.find(s => s.stu_code == this.tempID);
      
      student.stu_name = this.edit_name;
      student.stu_surname =this.edit_Sname;
      student.stu_code = this.edit_id;
      student.stu_pass = ((this.edit_pass == null || this.edit_pass == "")? '1234' : this.edit_pass);

      this._studentService.updateStudent(student,this.tempID).subscribe(res => {

        if(res){
          setTimeout(() => {
            this.updatePage();}, 2000);
             
        }
        else{
          alert("Internal Server Error while updating");
        }

      },error =>{
        alert(error);
      });
      this.isEdit = false;
  }
  
  closeEdit(){
    this.isEdit = false;
  }
  closeAdd(){
    this.isAdd = false;
  }
}