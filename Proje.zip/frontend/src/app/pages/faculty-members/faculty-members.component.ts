import { FacultyMember } from './../../models/faculty-member';
import { FacultyMemberService } from './../../services/faculty-member-service/faculty-member.service';
import { Component, OnInit } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-faculty-members',
  templateUrl: './faculty-members.component.html',
  styleUrls: ['./faculty-members.component.css']
})
export class FacultyMembersComponent implements OnInit {
    public in_id :number;
    public in_name :string ="";
    public in_Sname: string="";
    public in_mail: string = "";
    public in_Sdate: string ="";
    public facultyMembers = [];
    private edit_id: number;
    private edit_name :string;
    private edit_Sname :string;
    private edit_mail :string;
    private edit_Sdate: string;
    private tempID: number;
    public isAdd = false;
    public isEdit = false;
    

  constructor(private _facultyMemberService: FacultyMemberService) { }

  ngOnInit(): void {
   this.updatePage();

  }
  updatePage(){
    this._facultyMemberService.getMembers().pipe().subscribe(data=>{  
      
      this.facultyMembers = data;
   });
  }
  add(){
    if(this.isAdd ){
        if ( this.in_id == null || this.in_name == null  || this.in_Sname == null)
        {return;}
        let member: FacultyMember = {aca_code: this.in_id, aca_name: this.in_name, aca_surname: this.in_Sname, 
                    email: this.in_mail,startdate: this.in_Sdate}
        console.log(member);
        this._facultyMemberService.addMember(member).subscribe(res => {

          if(res){
            setTimeout(() => {
              this.updatePage();}, 2000);
               
          }
          else{
            alert("Internal Server Error While Adding");
          }

        });;
        //this.facultyMembers = this._facultyMemberService.getMembers();
      
         this.in_name =  this.in_Sname =  this.in_mail =  this.in_Sdate =this.in_id =null;
    }
    this.isAdd = !this.isAdd;
  }

  openEdit(id:number){

    this.tempID = id;
    let member = this.facultyMembers.find(s => s.aca_code == id);
    this.edit_name = member.aca_name;
    this.edit_Sname = member.aca_surname;
    this.edit_id = member.aca_code;
    this.edit_mail = member.email;
    this.edit_Sdate = member.start_date;
    this.isEdit = true;
  }
  edit(){
    
    let member = this.facultyMembers.find(s => s.aca_code == this.tempID);
    member.aca_name = this.edit_name;
    member.aca_surname =this.edit_Sname;
    member.aca_code = this.edit_id ;
    member.email = this.edit_mail;
    member.start_date =this.edit_Sdate;
    this._facultyMemberService.updateMember(member,this.tempID).subscribe(res => {

      if(res){
        setTimeout(() => {
          this.updatePage();}, 2000);
           
      }
      else{
        alert("Internal Server Error While Updating");
      }

    });;
    this.isEdit = false;
  }

  remove(id:number){
    if(this.tempID == id){
      this.isEdit = false;
    }
  this._facultyMemberService.removeMember(id).subscribe(res => {

    if(res){
      setTimeout(() => {
        this.updatePage();}, 2000);
         
    }
    else{
      alert("Internal Server Error While Removing");
    }

  });
  }

  closeEdit(){
    this.isEdit = false;
  }
  closeAdd(){
    this.isAdd = false;
  }

}
