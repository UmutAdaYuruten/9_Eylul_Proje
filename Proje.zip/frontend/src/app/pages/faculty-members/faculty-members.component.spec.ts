import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacultyMembersComponent } from './faculty-members.component';

describe('FacultyMembersComponent', () => {
  let component: FacultyMembersComponent;
  let fixture: ComponentFixture<FacultyMembersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacultyMembersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacultyMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
