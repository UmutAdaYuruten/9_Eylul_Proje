import { Classroom } from './../../models/classroom';
import { ClassroomService } from './../../services/classroom-service/classroom.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-classrooms',
  templateUrl: './classrooms.component.html',
  styleUrls: ['./classrooms.component.css']
})
export class ClassroomsComponent implements OnInit {

  private in_id ;
  private in_name :string ;
  private in_type: string;
  private in_parent: string;

  private edit_id;
  private edit_name :string;
  private edit_type :string;
  private edit_parent :string;


  private isAdd = false;
  private isEdit:boolean = false;
  private classes:Classroom[] = [];
  private yesText:string = 'Yes';
  private noText:string = 'No';
  private tempID: string;
  private floorText: string = "Floor";
  private classText: string = "Classroom";
  private naText :string = ""; 

  constructor(private _classroomService: ClassroomService) { }

  ngOnInit(): void {
    this.updatePage();
  }

  updatePage(){
    this._classroomService.getClassrooms().subscribe(data=>{  
      
      this.classes = data;
      
   });
  }

  add(){
    
    if(this.isAdd){
        if(this.in_id == null || this.in_name == null || this.in_type == null  ){alert("In error"); return;}    
        let tempMan :number;
        if (this.in_type == 'Floor') {tempMan = 0;}
        else if (this.in_type == 'Classroom') {tempMan = 1;}
        else{return;}

        if(tempMan == 1 && this.in_parent == "" ){ alert("Parent Error"); return;}

        let classroom : Classroom = {class_code: this.in_id, class_name:this.in_name, type:tempMan, parentcode: this.in_parent};
        
        this._classroomService.addClassroom(classroom).subscribe(res => {
          if(res){
            setTimeout(() => {
              this.updatePage();}, 2000);
               
          }
          else{
            alert("Internal Server Error While Adding");
          }

        });
        this.in_id = this.in_name = this.in_type = this.in_parent = null;
       
    }
   
    this.isAdd = !this.isAdd;
}
remove(id:string){ 
    if(this.tempID == id){
        this.isEdit = false;
    }
    
    this._classroomService.removeClassroom(id).subscribe(res => {

      if(res){
        setTimeout(() => {
          this.updatePage();}, 50);
           
      }
      else{
        alert("Internal Server Error while removing");
      }

    });
    return true;
}
openEdit(id:string){

    this.tempID = id;
    let classroom = this.classes.find(s => s.class_code == id);
    this.edit_name = classroom.class_name;
    this.edit_type = (classroom.type == 1)? 'Class' : 'Floor';
    this.edit_id = classroom.class_code;
    this.edit_parent = (classroom.type == 1)? classroom.parentcode : 'None';
    this.isEdit = true;
    return true;
}
edit(){
    
  let classroom = this.classes.find(s => s.class_code == this.tempID);
  if (this.edit_type == 'Classroom' && this.edit_parent != null){classroom.type = 1; classroom.parentcode = this.edit_parent;}
  else if(this.edit_type == 'Floor') {classroom.type = 0; classroom.parentcode = null;}
  else {return;}

  classroom.class_name = this.edit_name;

  classroom.class_code = this.edit_id ;
    
    this._classroomService.updateClassroom(classroom,this.tempID).subscribe(res => {

      if(res){
        setTimeout(() => {
          this.updatePage();}, 2000);
           
      }
      else{
        alert("Internal Server Error while updating");
      }

    });
    this.isEdit = false;
    return true;

    
}

}
