import { CourseService } from './../../services/course-service/course.service';
import { Component, OnInit } from '@angular/core';
import { Course } from 'app/models/course';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  private in_id ;
  private in_name :string ;
  private in_type: string;
  private edit_id;
  private edit_name :string;
  private edit_type :string;
  private edit_number :number;
  private editArr :boolean[] = [];
  private isAdd = false;
  private isEdit:boolean = false;
  private courses:Course[] = [];
  private yesText:string = 'Yes';
  private noText:string = 'No';
  private tempID: string;

  constructor(private _courseService :CourseService){}

  ngOnInit(){
      
    this.updatePage();
  }  

  updatePage(){
    this._courseService.getCourses().subscribe(data=>{  
      
      this.courses = data;
      
   });
  }
  add(){
    
      if(this.isAdd){
          if(this.in_id == null || this.in_name == null || this.in_type == null  ){return;}    
          let tempMan :number;
          if (this.in_type == 'Yes') {tempMan = 1;}
          else if (this.in_type == 'No') {tempMan = 0;}
          else{return;}
          let course : Course = {course_code: this.in_id,course_name:this.in_name,ismandatory:tempMan};
          
          this._courseService.addCourse(course).subscribe(res => {

            if(res){
              setTimeout(() => {
                this.updatePage();}, 2000);
                 
            }
            else{
              alert("Internal Server Error While Adding");
            }
 
          });
          this.in_id = this.in_name = this.in_type =null;
         
      }
      this.isAdd = !this.isAdd;
  }
  remove(id:string){ 
      if(this.tempID == id){
          this.isEdit = false;
      }
      
      this._courseService.removeCourse(id).subscribe(res => {

        if(res){
          setTimeout(() => {
            this.updatePage();}, 50);
             
        }
        else{
          alert("Internal Server Error while removing");
        }

      });
      return true;
  }
  openEdit(id:string){

      this.tempID = id;
      let course = this.courses.find(s => s.course_code == id);
      this.edit_name = course.course_name;
      this.edit_type = (course.ismandatory == 1)? 'Yes' : 'No';
      this.edit_id = course.course_code;
      this.isEdit = true;
      return true;
  }
  edit(){
      
    let course = this.courses.find(s => s.course_code == this.tempID);
    if (this.edit_type == 'Yes'){course.ismandatory = 1;}
    else if(this.edit_type == 'No') {course.ismandatory = 0;}
    else {return;}

    course.course_name = this.edit_name;

    course.course_code = this.edit_id ;
      
      this._courseService.updateCourse(course,this.tempID).subscribe(res => {

        if(res){
          setTimeout(() => {
            this.updatePage();}, 2000);
             
        }
        else{
          alert("Internal Server Error while updating");
        }

      });
      this.isEdit = false;
      return true;

      
  }
  closeEdit(){
    this.isEdit = false;
  }
  closeAdd(){
    this.isAdd = false;
  }

  
}
