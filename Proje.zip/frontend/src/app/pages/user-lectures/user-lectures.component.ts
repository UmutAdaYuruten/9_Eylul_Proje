import { Register } from './../../models/register';
import { Lecture } from './../../models/lecture';
import { UserService } from './../../services/user-service/user.service';
import { StudentService } from './../../services/student-service/student.service';
import { Student } from 'app/models/student';
import { Component, OnInit } from '@angular/core';
import { LectureService } from 'app/services/lecture-service/lecture.service';
import { AuthenticationService } from 'app/services/authentication-service/authentication.service';

@Component({
  selector: 'app-user-lectures',
  templateUrl: './user-lectures.component.html',
  styleUrls: ['./user-lectures.component.css']
})
export class UserLecturesComponent implements OnInit {

  public lectures :Lecture[] = [];

    public in_id :string ="";
    public in_Cid :string ="";
    public in_floor: string="";
    public in_day:string="";
    public in_hour:string="";
    public in_class:string="";
    private student:Student;
    private tempID;
    private userLecture = [];
    private currentLectures;
  constructor(private _lectureService: LectureService, private _studentService:StudentService, private authenticationService:AuthenticationService,
    private _userService: UserService) { 
      
    }


  ngOnInit(): void {
    this.tempID = this.authenticationService.getCurrentUser().id;
  
    
   this.updatePage();
  }

  updatePage(){
    this.currentLectures = this._userService.getCurrentLectures();
    this._lectureService.getLectures().pipe().subscribe(data=>{  
      this.lectures = data;
    });
    

    this._userService.getUserLectures( this.tempID).pipe().subscribe(data=>{  
      this.userLecture = data;
    });
  }

  addLecture(lecture:Lecture){
    
    let register :Register = {l_code: lecture.lec_code, co_code: lecture.c_code, student_code: this.tempID,sem_code: 20211, grade:null};
    this._userService.addLecture(register).subscribe(res => {
          
      console.log("Front request add lecture");
      
      if(res){
        setTimeout(() => {
          
          this.updatePage();}, 2000);
          
         
      }
      else{
        alert("Internal Server Error While Adding");
      }

    }, error => {alert(error)});
    
  }

  checkLecture(c_id:string){
   

    let alec = this.currentLectures.find(l => l.co_code == c_id)
    if(alec != null && alec != undefined ){
      return true;
    }
    return false;
    }

  removeLecture(c_id:string){
    
  let outP = c_id + "~" + this.tempID;
   this._userService.removeLecture(outP).subscribe(res => {
      if(res){
        setTimeout(() => {
          this.updatePage();},100);
      }
      else{
        alert("Internal Server Error while removing");
      }

    }, error => {alert(error)});
    var tempI = this.currentLectures.indexOf(this.currentLectures.find(s=>s.co_code == c_id && s.student_code == this.tempID));

    while(tempI != -1){
      this.currentLectures.splice(tempI,1);
      tempI = this.currentLectures.indexOf(this.currentLectures.find(s=>s.co_code == c_id && s.student_code == this.tempID));
    }
    this._userService.setCurrentLectures(this.currentLectures);
    
    return true;
 
  }
  
 
}
