import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLecturesComponent } from './user-lectures.component';

describe('UserLecturesComponent', () => {
  let component: UserLecturesComponent;
  let fixture: ComponentFixture<UserLecturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserLecturesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserLecturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
