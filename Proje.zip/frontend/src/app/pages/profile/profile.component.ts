import { AuthenticationService } from 'app/services/authentication-service/authentication.service';
import { UserService } from './../../services/user-service/user.service';
import { StudentService } from './../../services/student-service/student.service';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'profile-cmp',
    moduleId: module.id,
    templateUrl: 'profile.component.html'
})

export class ProfileComponent implements OnInit{
    private student = [];
    private studentLectures = [];

    private name_place;
    private surname_place;
    constructor(private _studentService: StudentService,private _userService: UserService,private authenticationService:AuthenticationService)
    {}
    ngOnInit(){
      
      let i = this.authenticationService.getCurrentUser().id;

      this._userService.getUser(i).pipe().subscribe(data=>{  
      
        this.studentLectures = data;
        this._userService.setCurrentLectures(this.studentLectures);
        this.name_place = this.studentLectures[0].stu_name;
        this.surname_place = this.studentLectures[0].stu_surname;
       
     });

  
      
    }

}