





import { User } from 'app/models/user';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { UserService } from './../../services/user-service/user.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from 'app/services/authentication-service/authentication.service';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  public userId = "userID";
  public userPassword = "userPass";
  public failMsg = true;
  public failedMsg ="false";
  public errorMsg = "Login Failed";
  

  loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    error = '';
  

  constructor( private _userService :UserService, private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService) { 
      if (this.authenticationService.currentUserValue) { 
      this.router.navigate(['/']);
  }}
  ngOnInit(): void {
    this.authenticationService.getAll();
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });

  // get return url from route parameters or default to '/'
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }

    this.loading = true;
    this.authenticationService.login(this.f.username.value, this.f.password.value)  
        .subscribe(
            data => {
              
                let curUser = this.authenticationService.getCurrentUser();
                if(curUser.type === 'student'){
                  this.router.navigateByUrl('user');
                }
                else{
                  this.router.navigateByUrl('admin');
                }
                
                
            },
            error => {
                this.error = error;
                this.loading = false;
            });
  }
}
