export class Course{
    course_code:string;
    course_name:string;
    ismandatory:number;
}