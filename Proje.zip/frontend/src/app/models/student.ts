import { Lecture } from './lecture';
export class Student{
    stu_code: number;
    stu_name: string;
    stu_surname: string;
    stu_pass:string;
}