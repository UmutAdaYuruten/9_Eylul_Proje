export class Register{
    
    l_code:string;
    co_code:string;
    student_code:number;
    sem_code:number;
    grade:string;
}