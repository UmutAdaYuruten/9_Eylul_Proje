export class Classroom{
    class_code:string;
    class_name:string;
    type:number;
    parentcode:string;

}