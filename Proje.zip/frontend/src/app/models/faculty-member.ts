export class FacultyMember{
    aca_code: number;
    aca_name:string;
    aca_surname: string;
    email:string;
    startdate:string;
    
}