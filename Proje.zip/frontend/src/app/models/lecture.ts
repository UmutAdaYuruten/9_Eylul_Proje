import { Classroom } from './classroom';

export class Lecture{
    lec_code: string;
    c_code:string;
    day:number;
    hour:string;
    a_code:number;
    class_no:string;

    
 
    
    
}
