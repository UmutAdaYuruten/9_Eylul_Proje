import { ProfileComponent } from '../../pages/profile/profile.component';
import { UserLecturesComponent } from '../../pages/user-lectures/user-lectures.component';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserLayoutRoutes } from './user-layout.routing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
    imports: [
      CommonModule,
      RouterModule.forChild(UserLayoutRoutes),
      FormsModule,
      NgbModule
    ],
    declarations: [
     UserLecturesComponent,
     ProfileComponent,
    ]
  })
  
  export class UserLayoutModule {}