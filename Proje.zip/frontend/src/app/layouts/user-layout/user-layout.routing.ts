import { ProfileComponent } from '../../pages/profile/profile.component';
import { UserLecturesComponent } from '../../pages/user-lectures/user-lectures.component';
import { Routes } from '@angular/router';
import { AuthGuard } from '../../_helpers';
export const UserLayoutRoutes: Routes = [
    { path : '',         redirectTo:'profile',          pathMatch:'full'},
    { path : 'profile',  component: ProfileComponent, canActivate :  [AuthGuard] },
    { path : 'lectures', component: UserLecturesComponent, canActivate :  [AuthGuard] },
    
   
];