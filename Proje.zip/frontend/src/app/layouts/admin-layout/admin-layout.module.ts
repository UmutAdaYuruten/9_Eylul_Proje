import { ProfileComponent } from './../../pages/profile/profile.component';
import { ClassroomsComponent } from './../../pages/classrooms/classrooms.component';
import { CoursesComponent } from '../../pages/courses/courses.component';

import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AdminLayoutRoutes } from './admin-layout.routing';






import { LecturesComponent}         from '../../pages/lectures/lectures.component';
import { FacultyMembersComponent } from '../../pages/faculty-members/faculty-members.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StudentsComponent } from 'app/pages/students/students.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    NgbModule
  ],
  declarations: [
    ProfileComponent,
    LecturesComponent,
    FacultyMembersComponent,
    StudentsComponent,
    CoursesComponent,
    ClassroomsComponent,
  ]
})

export class AdminLayoutModule {}
