import { ProfileComponent } from './../../pages/profile/profile.component';
import { ClassroomsComponent } from './../../pages/classrooms/classrooms.component';
import { CoursesComponent } from '../../pages/courses/courses.component';

import { Routes } from '@angular/router';






import { LecturesComponent } from '../../pages/lectures/lectures.component';
import { FacultyMembersComponent } from '../../pages/faculty-members/faculty-members.component';
import { AuthGuard } from '../../_helpers';
import { StudentsComponent } from 'app/pages/students/students.component';
export const AdminLayoutRoutes: Routes = [
    { path: '',     redirectTo:'students',     pathMatch:'full'},
    { path: 'students',          component: StudentsComponent , canActivate :  [AuthGuard]},
    { path: 'courses',          component: CoursesComponent, canActivate :  [AuthGuard] }, 
    { path: 'classrooms',          component: ClassroomsComponent, canActivate :  [AuthGuard] },    
    { path: 'profile',           component: ProfileComponent , canActivate :  [AuthGuard]},  
    { path: 'lectures',       component: LecturesComponent, canActivate :  [AuthGuard]},
    { path: 'faculty-members', component: FacultyMembersComponent, canActivate :  [AuthGuard]},
    
];
