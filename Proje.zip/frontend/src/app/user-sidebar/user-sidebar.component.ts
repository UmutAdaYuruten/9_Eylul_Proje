import { Component, OnInit } from '@angular/core';


export interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}

export const ROUTES: RouteInfo[] = [
  { path: '/user/profile',          title: 'Profile',           icon:'nc-single-02',         class: ''},
  { path: '/user/lectures',         title: 'Lectures',          icon:'nc-alert-circle-i',    class: '' },
  
   
];

@Component({
    moduleId: module.id,
    selector: 'user-sidebar-cmp',
    templateUrl: 'user-sidebar.component.html',
})

export class UserSidebarComponent implements OnInit {
    public menuItems: any[];
    ngOnInit() {
        this.menuItems = ROUTES.filter(menuItem => menuItem);
    }
}