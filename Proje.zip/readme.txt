front-end'i kurmak için npm install kullanın.
back-end kendinden hazır
admin ve öğrenci girişleri için veriler login-info.txt'de
